import numpy as np
import pandas as pd
import matplotlib.pyplot as plt



# IMPORTING THE DATASET

dataset=pd.read_csv('pre_data.csv')
print("Dataset : ",dataset)

x=dataset.iloc[:,:-1].values
y=dataset.iloc[:,-1].values

print("\nx value : ",x)
print("\ny value : ",y)


# TAKING CARE OF MISSING VALUES


from sklearn.impute import SimpleImputer 

imputer=SimpleImputer(missing_values=np.nan,strategy="mean")

imputer.fit(x[:,1:3])
x[:,1:3]=imputer.transform(x[:,1:3])

print("\nx value : ",x)


# ENCODING THE CATEGORICAL DATA

# 1.FOR INDEPENDENT VARIABLES


from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder

col_trans=ColumnTransformer(transformers=[('encoder',OneHotEncoder(),[0])],remainder='passthrough')


x=np.array(col_trans.fit_transform(x))

print("\nx transform : ",x)



# FOR DEPENDENT VARIABLES


from sklearn.preprocessing import LabelEncoder
label_encode=LabelEncoder()


y=label_encode.fit_transform(y)

print("\ny encoding : ",y)



# SPLITING THE DATASET INTO TRAINING AND TESTING SETS

from sklearn.model_selection import train_test_split

x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=1)

print("\nx_train : ",x_train)
print("\nx_test : ",x_test)






print("\ny_train : ",y_train)
print("\ny_test : ",y_test)



# FEATURE SCALING : USING StandardScaler 



from sklearn.preprocessing import StandardScaler

std_scaler=StandardScaler()


x_train[:,3:]=std_scaler.fit_transform(x_train[:,3:])
x_test[:,3:]=std_scaler.transform(x_test[:,3:])


print("--Feature Scaling --")
print("\nx_train : ",x_train)
print("\nx_test : ",x_test)


