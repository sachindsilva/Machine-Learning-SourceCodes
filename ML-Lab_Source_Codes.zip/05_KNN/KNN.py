
# 5.K-Nearest Neighbors---> Take k=3 i.e, n_neighbors=3

import numpy as np  # FOR ARRAY MANIPULATIONS
import matplotlib.pyplot as plt  # FOR GRAPHICAL ANALYSIS
from sklearn.neighbors import KNeighborsClassifier  # KNN COMPUTATION
from sklearn.model_selection import train_test_split  # SPLIT THE DATASET
from sklearn.metrics import classification_report, confusion_matrix
# TO APPLY THIS PROBLEM ON 'iris' DATASET
from sklearn.datasets import load_iris


# IMPORTING THE  DATASET

iris_data = load_iris()


# ABSTRACTING THE  COLUMN 'data'
data = iris_data.data
print("Iris_Data : ", data)

# ABSTRACTING THE  COLUMN 'target'

target = iris_data.target
print("Iris_Target : ", target)


# SPLITTING THE DATASET INTO TRAINING AND TESTING SETS

x_train, x_test, y_train, y_test = train_test_split(
    data, target, test_size=0.2)


# TRAINING KNN MODEL

knn = KNeighborsClassifier(n_neighbors=3)

knn.fit(x_train, y_train)


y_predict = knn.predict(x_test)


# EVALUATING THE KNN
print("Confusion Matrix : ", confusion_matrix(y_test, y_predict))
print("\nClassification Report : ", classification_report(y_test, y_predict))


# VISUALIZING THE PREDICTIONS..


for i in range(3):
    r1 = np.where(y_predict == i)
    r2 = np.where(y_test == i)

    if (i == 0):
        m = '*'
        c = 'red'
    elif (i == 1):
        m = 'o'
        c = 'green'
    elif (i == 2):
        m = 'x'
        c = 'yellow'

    plot1 = plt.figure(1)
    plt.plot(x_test[r1, 1], x_test[r1, 0], marker=m, color=c)

    if (i == 0):
        m = '*'
        c = "violet"
    elif (i == 1):
        m = 'o'
        c = 'black'
    elif (i == 2):
        m = 'x'
        c = 'cyan'
    plot2 = plt.figure(2)
    plt.plot(x_test[r2, 1], x_test[r2, 0], marker=m, color=c)

plt.show()



print("KNN Score : ", knn.score(x_test, y_test))
print("x-axis predicted : ", x_test[r1, 1])
print("y-axis predicted : ", x_test[r1, 0])

print("x-axis inputted : ", x_test[r2, 1])
print("y-axis inputted : ", x_test[r2, 0])
