# Implement Find_S Algorithm for finding the most specific hypothesis based on the given set of training data samples.

import numpy as np
import pandas as pd

data=pd.read_csv('data.csv')
print("The Dataset is ",data)

features=data.iloc[:,:-1].values

print("Features :",features)


target=data.iloc[:,-1].values
print("Target :",target)

def train(feat,tar):
    for i,val in enumerate(tar):
        if val=="yes":
            specific_h=feat[i].copy()
            break
    for i,val in enumerate(feat):
        if tar[i]=="yes":
            for x in range(len(specific_h)):
                if val[x]!=specific_h[x]:
                    specific_h[x]="?"
                else:
                    pass
    return specific_h

print(train(features,target))
