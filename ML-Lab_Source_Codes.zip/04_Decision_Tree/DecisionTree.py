import pandas as pd
from sklearn.model_selection import train_test_split # FOR SPLITTING THE DATASET
from sklearn.tree import DecisionTreeClassifier # TO APPLY DECISION TREE ALGORITHM
from sklearn.preprocessing import LabelEncoder # TO CONVERT NON-NUMERICAL TO NUMERICAL VALUES
from sklearn import tree    # FOR CONSTRUCTING DECISION TREE
from sklearn import metrics # TO COMPUTE THE ACCURACY OF THE MODEL



# IMPORTING DATASET

data=pd.read_csv("tennis.csv")
print("--Dataset--\n",data)


all_cols=data.columns
features=all_cols[1:5]

# ENCODING THE ALL VALUES OF THE DATASET --> NON-NUMERICAL-NUMERICAL VALUES

for label in data.columns:
    data[label]=LabelEncoder().fit_transform(data[label])

inputs=data.iloc[:,:-1].values

target=data.iloc[:,1].values




# SPLITTING THE DATASET INTO TRAINING AND TESTING SETS
x_train,x_test,y_train,y_test=train_test_split(inputs,target,test_size=0.2)


id3=DecisionTreeClassifier()
id3=id3.fit(x_train,y_train)


#PREDICTING THE VALUES FROM MODEL
y_predict=id3.predict(x_test)



# DETERMINING THE ACCURACY PRODUCED BY THE MODEL
print("Accuracy Score : ",metrics.accuracy_score(y_test,y_predict))

# PLOTTING TREE USING PLOT_TREE 
tree.plot_tree(id3,feature_names=features)



